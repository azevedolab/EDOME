#!/usr/bin/env python3
#
################################################################################
# EDOME: Extended DOME (data, optimization, model, and evaluation)             #
################################################################################
#
# Code to read a CSV file and calculate the metrics and generate plots
# to evaluate the predictive peformance of scoring functions, energy terms, and
# machine learning models. This script employs the evaluation metrics defined by
# Walsh et al., 2021.
#
# Reference:
# Walsh I, Fishman D, Garcia-Gasulla D, Titma T, Pollastri G; ELIXIR Machine
# Learning Focus Group; Harrow J, Psomopoulos FE, Tosatto SCE. DOME:
# recommendations for supervised machine learning validation in biology. Nat
# Methods. 2021 Oct;18(10):1122-1127. doi: 10.1038/s41592-021-01205-4.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2024                                                             #
################################################################################
#
# Import section
import sklearn
import numpy as np
import scipy
import sys

# Show current version of Python, scikit-learn, NumPy, SciPy, system OS, and
# a message about MLRegMPy
#
print("="*29, "Library Information", "="*30)
print("Python version: {}".format(sys.version[0:6]))
print("Scikit-learn version: {}".format(sklearn.__version__))
print("NumPy version: {}".format(np.__version__))
print("SciPy version: {}".format(scipy.__version__))

# Show reference
print("="*34, "Reference", "="*34)
print("""
Walsh I, Fishman D, Garcia-Gasulla D, Titma T, Pollastri G; ELIXIR Machine
Learning Focus Group; Harrow J, Psomopoulos FE, Tosatto SCE. DOME:
recommendations for supervised machine learning validation in biology. Nat
Methods. 2021 Oct;18(10):1122-1127.
""")

# Show bar
print("="*79)

# Show message about EDOME
print("""EDOME: Extended DOME (data, optimization, model, and evaluation)""")

# Show bar
print("="*79)