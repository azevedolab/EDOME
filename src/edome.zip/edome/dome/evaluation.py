#!/usr/bin/env python3
#
################################################################################
# EDOME: Extended DOME (data, optimization, model, and evaluation)             #
################################################################################
#
# Code to read a CSV file and calculate the metrics and generate plots
# to evaluate the predictive peformance of scoring functions, energy terms, and
# machine learning models. This script employs the evaluation metrics defined by
# Walsh et al., 2021.
#
# Reference:
# Walsh I, Fishman D, Garcia-Gasulla D, Titma T, Pollastri G; ELIXIR Machine
# Learning Focus Group; Harrow J, Psomopoulos FE, Tosatto SCE. DOME:
# recommendations for supervised machine learning validation in biology. Nat
# Methods. 2021 Oct;18(10):1122-1127. doi: 10.1038/s41592-021-01205-4.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2024                                                             #
################################################################################
##
# Import section
import sys
import numpy as np
import pandas as pd
import csv
from scipy import stats
import warnings
from sklearn.metrics import max_error
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.metrics import median_absolute_error
from sklearn.metrics import mean_absolute_percentage_error
from sklearn.metrics import d2_absolute_error_score
from sklearn.metrics import d2_pinball_score
from sklearn.metrics import d2_tweedie_score
from sklearn.metrics import r2_score
import matplotlib.pyplot as plt
# https://matplotlib.org/stable/tutorials/colors/colormaps.html
from matplotlib import cm
from dome import metrics

# Define calc_RSS() function
def calc_RSS(x,y_pred):
    """Calculate Residual Sum of Squares (RSS)"""

    # Import section
    import numpy as np

    # Get number of data points
    n = len(x)

    # Set up array with zeros
    aux = np.zeros(n,dtype=float)

    # Calculate aux
    for i in range(n):
        aux[i] = (x[i] - y_pred[i])**2

    # Calculates Residual Sum of Squares (RSS)
    rss = np.sum(aux)

    # Return rss
    return rss

# Define Walsh_2021() class
class Walsh_2021(object):
    """Class to carry out statistical analysis (Walsh et al., 2021) of
    predictive peformance of models to predict binding affinity"""

    # Define constructor method
    def __init__(self,input_file):
        """Constructor method"""

        # Get attribute
        self.input_file = input_file

    # Define read_input() method
    def read_input(self):
        """Method to read an input file with the parameters necessary to
        carry out statistical analysis of a CSV file"""

        # Try to open a file
        try:
            fo_in = open(self.input_file,"r")
            csv_in = csv.reader(fo_in)
        except IOError:
            msg_out = "\nIOError! I can't fine file "+self.input_file
            sys.exit(msg_out)

        # Looping through csv_in
        for line in csv_in:
            if line[0].strip() == "file_in":
                self.file_in = line[1].strip()
            elif line[0].strip() == "exp_header":
                self.exp_header = line[1].strip()
            elif line[0].strip() ==  "ref_header":
                self.ref_header = line[1].strip()
            elif line[0].strip() == "n_plots":
                self.n_plots = int(line[1].strip())

                # Set up empty list
                self.list_plot_files = []

                # Loop to get input files with plotting parameters
                for i in range(self.n_plots):
                    self.list_plot_files.append(line[2+i].strip())

        # Close file
        fo_in.close()

    # Define read_plot_par_input() method
    def read_plot_par_input(self,plot_input):
        """Method to read an input file with the parameters necessary to
        generate plots"""

        # Try to open a file
        try:
            fo_in = open(plot_input,"r")
            csv_in = csv.reader(fo_in)
        except IOError:
            msg_out = "\nIOError! I can't fine file "+plot_input
            sys.exit(msg_out)

        # Looping through csv_in
        for line in csv_in:
            if line[0].strip() == "x_header":
                self.x_header = line[1].strip()
            elif line[0].strip() ==  "y_header":
                self.y_header = line[1].strip()
            elif line[0].strip() ==  "z_header":
                self.z_header = line[1].strip()
            elif line[0].strip() ==  "alpha1":
                self.alpha1 = float(line[1].strip())
            elif line[0].strip() ==  "size":
                self.size = int(line[1].strip())
            elif line[0].strip() ==  "alpha2":
                self.alpha2 = float(line[1].strip())
            elif line[0].strip() ==  "edgecolor":
                self.edgecolor = line[1].strip()
            elif line[0].strip() ==  "cbar_label":
                self.cbar_label = line[1].strip()
            elif line[0].strip() ==  "cbar_fontsize":
                self.cbar_fontsize = int(line[1].strip())
            elif line[0].strip() ==  "xlim":
                self.xlim1 = float(line[1].strip())
                self.xlim2 = float(line[2].strip())
            elif line[0].strip() ==  "ylim":
                self.ylim1 = float(line[1].strip())
                self.ylim2 = float(line[2].strip())
            elif line[0].strip() ==  "xlabel":
                self.xlabel = line[1].strip()
            elif line[0].strip() ==  "xlabel_fontsize":
                self.xlabel_fontsize = int(line[1].strip())
            elif line[0].strip() ==  "xlabel_labelpad":
                self.xlabel_labelpad = int(line[1].strip())
            elif line[0].strip() ==  "ylabel":
                self.ylabel = line[1].strip()
            elif line[0].strip() ==  "ylabel_fontsize":
                self.ylabel_fontsize = int(line[1].strip())
            elif line[0].strip() ==  "ylabel_labelpad":
                self.ylabel_labelpad = int(line[1].strip())
            elif line[0].strip() ==  "plot_format":
                self.plot_format = line[1].strip()
            elif line[0].strip() ==  "dpi_in":
                self.dpi_in = int(line[1].strip())
            elif line[0].strip() ==  "annotate_num":
                self.annotate_num = int(line[1].strip())
                self.annotate_par = []
            elif line[0].strip() == "annotate_par":
                aux = [line[1].strip(),float(line[2].strip()),
                float(line[3].strip()),int(line[4].strip())]
                self.annotate_par.append(aux)

        # Close file
        fo_in.close()

    # Define stats() method
    def stats(self):
        """Method to run statistical analysis of all features"""

        # Define output file name
        self.file_stats = self.file_in.replace(".csv","_stats.csv")

        # Show message
        msg_out = "\nDetermining metrics ("+self.file_stats+")..."
        print(msg_out,end="")

        # Source https://www.usepandas.com/csv/sort-csv-data-by-column
        #
        # Read in your .csv files as dataframes
        # df is a common standard for naming a dataframe. You can
        # name them something more descriptive as well.
        # Using a descriptive name is helpful when you are dealing
        # with multiple .csv files.
        df = pd.read_csv(self.file_in)

        # convert column names to a list
        cols_list = df.columns.tolist()

        # Get the column index where to start
        starting_col = cols_list.index(self.ref_header)

        # Get experimental data
        y_exp = df.loc[:,self.exp_header]

        # Set up an empty string
        lines_out = ""

        # Looping through data
        for col in cols_list[starting_col:]:

            # Get predicted values
            y_pred = df.loc[:,col]

            # Calculate Pearson
            rp,p_r = stats.pearsonr(y_exp,y_pred)

            # Calculate r2
            r2 = rp*rp

            # Calculate rho
            rho,p_rho = stats.spearmanr(y_exp,y_pred)

            # Calculate MSE
            mse = mean_squared_error(y_exp,y_pred)

            # Calculate RMSE
            rmse = mean_squared_error(y_exp,y_pred,squared=False)

            # Calculate log(RMSE)
            log_rmse = np.log10(rmse)

            # Calculate MAE
            mae = mean_absolute_error(y_exp,y_pred)

            # Calculate log(MAE)
            log_mae = np.log10(mae)

            # Calculate R2 (coefficient of determination)
            R2cd = r2_score(y_exp,y_pred)

            # Invoke calc_RSS() method
            rss = calc_RSS(y_exp,y_pred)

            # Calculate the unbiased sample standard deviation, i.e. it uses a
            # correction factor n / (n - 1).
            sigma1 = stats.tstd(y_pred)

            # Call metrics.calc() function
            DOME,EDOMER2,EDOMErho,EDOME = metrics.calc(rmse,mae,r2,rho,R2cd)

            # Calculate log(DOME)
            log_DOME = np.log10(DOME)

            # Calculate log(EDOMER2)
            log_EDOMER2 = np.log10(EDOMER2)

            # Calculate log(EDOMErho)
            log_EDOMErho = np.log10(EDOMErho)

            # Calculate log(EDOME)
            log_EDOME = np.log10(EDOME)

            # Add results to this_line
            this_line = col+","+str(rp)+","+str(p_r)+","+str(r2)+","+str(rho)
            this_line += ","+str(p_rho)+","+str(mse)
            this_line += ","+str(rmse)+","+str(log_rmse)+","+str(rss)
            this_line += ","+str(mae)+","+str(log_mae)+","+str(R2cd)
            this_line += ","+str(sigma1)
            this_line += ","+str(DOME)+","+str(log_DOME)
            this_line += ","+str(EDOMER2)+","+str(log_EDOMER2)
            this_line += ","+str(EDOMErho)+","+str(log_EDOMErho)
            this_line += ","+str(EDOME)+","+str(log_EDOME)+"\n"
            lines_out += this_line

        # Define header
        header = "Feature/Method,r,p-value(r),r2,rho,p-value(rho),MSE,RMSE,"
        header += "log(RMSE),RSS,MAE,log(MAE),R2,sigma,DOME,log(DOME),"
        header += "EDOMEr2,log(EDOMEr2),EDOMErho,log(EDOMErho),EDOME,log(EDOME)"
        header += "\n"

        # Open a new file
        fo_new = open(self.file_stats,"w")

        # Write data
        fo_new.write(header)
        fo_new.write(lines_out)

        # Close file
        fo_new.close()

        # Show message
        print("done!")

    # Define plotting() method
    def plotting(self):
        """Method to generate plot for predictive performance of scoring
        functions and energy terms"""

        # Source https://www.usepandas.com/csv/sort-csv-data-by-column
        #
        # Read in your .csv files as dataframes
        # df is a common standard for naming a dataframe. You can
        # name them something more descriptive as well.
        # Using a descriptive name is helpful when you are dealing
        # with multiple .csv files.
        df = pd.read_csv(self.file_stats)

        # Get data for plotting
        x = df.loc[:,self.x_header.strip()]
        y = df.loc[:,self.y_header.strip()]
        z = df.loc[:,self.z_header.strip()]

        # Colors for color map
        colors = z

        # Plotting
        plt.grid(alpha=self.alpha1)
        plt.scatter(x, y, s=self.size, alpha=self.alpha2, c=colors,
                edgecolor=self.edgecolor,linewidth=1,cmap=cm.rainbow)
        cbar = plt.colorbar()
        cbar.set_label(self.cbar_label,fontsize=self.cbar_fontsize)
        plt.xlim(self.xlim1,self.xlim2)
        plt.ylim(self.ylim1,self.ylim2)
        plt.xlabel(self.xlabel,fontsize = self.xlabel_fontsize,
                                                labelpad=self.xlabel_labelpad)
        plt.ylabel(self.ylabel,fontsize = self.ylabel_fontsize,
                                                labelpad=self.ylabel_labelpad)

        # Annotate the point xy with text text
        # Loop to add text
        if self.annotate_num > 0:
            for i in range(self.annotate_num):
                aux_par = self.annotate_par[i]
                plt.annotate(aux_par[0],(aux_par[1],aux_par[2]),
                                                    fontsize=aux_par[3])

        # Define plot_file
        plot_file = self.file_in.replace(".csv",
                    "_"+self.x_header+"_"+self.y_header+"."+self.plot_format)

        # Show message
        print("\nGenerating plot ("+plot_file+")...",end="")

        # Save plot on pdf file (or .tiff, .jpg, .png)
        plt.savefig(plot_file,dpi=self.dpi_in)

        # Show message
        print("done!")

        # Close plot
        plt.close()

    # Define bundle() method
    def bundle(self):
        """Method to run all steps necessary for the statistical analysis of all
        features"""

        # Ignore warnings
        warnings.filterwarnings('ignore')

        # Invoke self.read_input() method
        self.read_input()

        ########################################################################
        # Metrics stuff                                                        #
        ########################################################################
        # Invoke stats() method
        self.stats()

        ########################################################################
        # Plotting stuff                                                       #
        ########################################################################
        #
        # Looping through self.list_plot_files
        for line in self.list_plot_files:
            # Invoke read_plot_par_input() method
            self.read_plot_par_input(line)

            # Invoke plotting() method
            self.plotting()