#!/usr/bin/env python3
#
################################################################################
# EDOME: Extended DOME (data, optimization, model, and evaluation)             #
################################################################################
#
# Code to read a CSV file and calculate the metrics and generate plots
# to evaluate the predictive peformance of scoring functions, energy terms, and
# machine learning models. This script employs the evaluation metrics defined by
# Walsh et al., 2021.
#
# Reference:
# Walsh I, Fishman D, Garcia-Gasulla D, Titma T, Pollastri G; ELIXIR Machine
# Learning Focus Group; Harrow J, Psomopoulos FE, Tosatto SCE. DOME:
# recommendations for supervised machine learning validation in biology. Nat
# Methods. 2021 Oct;18(10):1122-1127. doi: 10.1038/s41592-021-01205-4.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2024                                                             #
################################################################################
#
# To run this script:
# python edome.py input_file
#
# python edome.py edome.in
#
# Import section
import sys
from datetime import datetime
from dome import evaluation

# Define main() function
def main():

    # Get input
    input_file = sys.argv[1]

    # Get start_time
    start_time = datetime.now()

    # Instantiate an object of Walsh_2021() class
    w1 = evaluation.Walsh_2021(input_file)

    # Invoke bundle() method
    w1.bundle()

    # Get end_time
    end_time = datetime.now()

    # Show duration
    print()
    print("="*79)
    print("Duration: {}".format(end_time - start_time))
    print("="*79)

# Call main() function
main()